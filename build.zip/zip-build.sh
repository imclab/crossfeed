#!/bin/sh
#< zip-build.sh - 20121025 - Zip up the build components...
BN=`basename $0`

wait_for_input()
{
    if [ "$#" -gt "0" ] ; then
        echo "$1"
    fi
    echo -n "$BN: Enter y to continue : "
    read char
    if [ "$char" = "y" -o "$char" = "Y" ]
    then
        echo "$BN: Got $char ... continuing ..."
    else
        if [ "$char" = "" ] ; then
            echo "$BN: Aborting ... no input!"
        else
            echo "$BN: Aborting ... got $char!"
        fi
        exit 1
    fi
}

ask()
{
    wait_for_input "$BN: *** CONTINUE? ***"
}

TMPSRC="../fgx-cf"
ZIPFIL="build.zip"
TMPZIP="$TMPSRC/$ZIPFIL"
TMPSELF="../build-fgx-cf/zip-build.sh"
TMPFIL="zip-build.txt"
if [ ! -f "$TMPFIL" ]; then
    echo "$BN: Error: Can NOT locate file list file [$TMPFIL]! Aborting..."
    exit 1
fi

ZIPOPTS="-j -o"

if [ ! -d "$TMPSRC" ]; then
    echo "$BN: Error: Can NOT locate source! [$TMPSRC]"
    exit 1
fi

if [ ! -f "$ZIPFIL" ] && [ -f "$TMPZIP" ]; then
    cp -a -v $TMPZIP .
    echo "$BN: Copied zip from source to do update..."
fi

if [ -f "$ZIPFIL" ]; then
    echo "$BN: This is an update"
    ZIPOPTS="$ZIPOPTS -u"
fi

# FILES="build-cf.sh build-cf.bat zip-build.sh ... see $TMPFIL for list
FILES=
echo "$BN: Reading and processing input file $TMPFIL"
WCNT=0
FCNT=0
while read LINE; do
    if [ -f "$LINE" ]; then
        FILES="$FILES $LINE"
        # echo "$BN: Added file [$LINE]"
        FCNT=`expr $FCNT + 1`
    else
        echo ""
        echo "$BN: WARNING: File [$LINE] NOT found"
        echo ""
        WCNT=`expr $WCNT + 1`
    fi
done < $TMPFIL

ZIPLIST=""
for arg in $FILES; do
    if [ -f "$arg" ]; then
        ZIPLIST="$ZIPLIST $arg"
    fi
done

if [ ! "$WCNT" = "0" ]; then
    echo "$BN: Note $WCNT files NOT FOUND!"
fi

echo "$BN: From $TMPFIL, found $FCNT files to add to $ZIPFIL"

echo "$BN: Will do: 'zip $ZIPOPTS $ZIPFIL $ZIPLIST'"

ask

echo "$BN: Doing: 'zip $ZIPOPTS $ZIPFIL $ZIPLIST'"

zip $ZIPOPTS $ZIPFIL $ZIPLIST

if [ ! -f "$ZIPFIL" ]; then 
	echo "$BN: Zipping FAILED!"
	exit 1
fi

unzip -l $ZIPFIL
echo "$BN: Copy zip to SOURCE - $TMPZIP?"
ask
echo "$BN: Doing 'cp -a $ZIPFIL $TMPZIP'"

cp -a $ZIPFIL $TMPZIP

# eof - zip-build.sh

