#!/bin/sh
#< zip-build.sh - 20121229 - 20121221 - 20121025 - Zip up the build components...
BN=`basename $0`

wait_for_input()
{
    if [ "$#" -gt "0" ] ; then
        echo "$1"
    fi
    echo -n "$BN: Enter y to continue : "
    read char
    if [ "$char" = "y" -o "$char" = "Y" ]
    then
        echo "$BN: Got $char ... continuing ..."
    else
        if [ "$char" = "" ] ; then
            echo "$BN: Aborting ... no input!"
        else
            echo "$BN: Aborting ... got $char!"
        fi
        exit 1
    fi
}

ask()
{
    wait_for_input "$BN: *** CONTINUE? ***"
}

TMPSRC="../crossfeed"
ZIPFIL="build.zip"
TMPZIP="$TMPSRC/$ZIPFIL"
TMPSELF="../build-cf/zip-build.sh"
TMPFIL="zip-build.txt"
ZIPOPTS="-j -o"

if [ ! -f "$TMPFIL" ]; then
    echo "$BN: Error: Can NOT locate file list file [$TMPFIL]! Aborting..."
    exit 1
fi

if [ ! -d "$TMPSRC" ]; then
    echo "$BN: Error: Can NOT locate source! [$TMPSRC]! Aborting..."
    exit 1
fi

if [ ! -f "$ZIPFIL" ] && [ -f "$TMPZIP" ]; then
    echo "$BN: Copying $TMPZIP to here for update..."
    cp -a $TMPZIP .
fi

if [ -f "$ZIPFIL" ]; then
    echo "$BN: This is an update of"
    ls -al $ZIPFIL
    ZIPOPTS="$ZIPOPTS -u"
fi

FILES=
echo "$BN: Reading and processing input file $TMPFIL"
while read LINE; do
    if [ -f "$LINE" ]; then
        FILES="$FILES $LINE"
        # echo "$BN: Added file [$LINE]"
    else
        echo "$BN: File [$LINE] NOT found"
    fi
done < $TMPFIL

ZIPLIST=""
for arg in $FILES; do
    if [ -f "$arg" ]; then
        ZIPLIST="$ZIPLIST $arg"
    fi
done

echo "$BN: Will do: 'zip $ZIPOPTS $ZIPFIL $ZIPLIST'"

ask

echo "$BN: Doing: 'zip $ZIPOPTS $ZIPFIL $ZIPLIST'"

zip $ZIPOPTS $ZIPFIL $ZIPLIST

if [ ! -f "$ZIPFIL" ]; then 
	echo "$BN: Zipping FAILED!"
	exit 1
fi

# show the list in the ZIP
unzip -l $ZIPFIL
echo "$BN: Copy zip to SOURCE - $TMPZIP?"

ask

echo "$BN: Doing 'cp -a $ZIPFIL $TMPZIP'"
cp -a $ZIPFIL $TMPZIP

# eof
