#!/bin/sh

FILES="cf_client cf_server test_pg test_pg2 test_http"

for arg in $FILES; do
   if [ -f "$arg" ]; then
     rm -f -v $arg
   else
     echo "$arg already deleted"
   fi
done

